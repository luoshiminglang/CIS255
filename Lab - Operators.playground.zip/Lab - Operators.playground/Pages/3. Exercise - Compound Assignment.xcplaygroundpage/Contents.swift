/*:
 ## Exercise - Compound Assignment
 
 Declare a variable whose value begins at 10. Using addition, update the value to 15 using the compound assignment operator. Using multiplication, update the value to 30 using compound assignment. Print out the variable's value after each assignment.
 */
var beginNumber  = 10
print("beginNumber is 10 is, \(beginNumber). ")
beginNumber += 5
print("update number of 15 is, \(beginNumber). ")
beginNumber *= 2
print("update number of 30 is, \(beginNumber). ")

/* missed meaning of problem
let beginsNumber = 10
var index: Int = 10
var sum: Int = 0
var multiplication: UInt64 = 1
var index1: UInt64 = 10
//print( "index =", index )
while index  < 16 {
    sum += index
    print( "index =", index )
    index += 1
}
print ("sum is", sum)
//index = 10
//print( "index1 =", index1 )
while index1  < 25 {
    multiplication *= index1
    print( "index1 =", index1 , multiplication)
    index1 += 1
    
}
print (" multiplication is", multiplication )
//the ma
*/
/*:
 Create a variable called `piggyBank` that begins at 0. You will use this to keep track of money you earn and spend. For each point below, use the right compound assignment operator to update the balance in your piggy bank.
 
 - Your neighbor gives you 10 dollars for mowing her lawn
 - You earn 20 more dollars throughout the week doing odd jobs
 - You spend half your money on dinner and a movie
 - You triple what's left in your piggy bank by washing windows
 - You spend 3 dollars at a convenience store
 
 Print the balance of your piggy bank after each step.
 */
var piggyBank: Int = 0
var balance: Int = 0
balance += 10
print("neighbor give you 10 dollar, balance is",balance)
balance += 20
print("earn 20 dollar, balance is ",balance)
balance -= balance/2
print("spend half the balance is", balance)
balance += balance * 2
print("tripple after, balance is ", balance)
balance -= 3
print("Spend 3 dollar, balance is",balance)







 





//: [Previous](@previous)  |  page 3 of 8  |  [Next: App Exercise - Counting](@next)
