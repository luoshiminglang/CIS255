//
//  ViewController.swift
//  interfaceBuilderBasics2
//
//  Created by user182345 on 11/22/20.
//  Copyright © 2020 user182345. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var mainLabel: UILabel!
    
    
    
    
    
    @IBOutlet var press: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
//        myButton.setTitleColor(.red, for: .normal)
    }

    @IBAction func changTitle(_ sender: Any) {
        print("OK")
        mainLabel.text = "This app rockes"
    }
    
}

