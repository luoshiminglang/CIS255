//
//  ViewController.swift
//  Light
//
//  Created by user182345 on 11/24/20.
//  Copyright © 2020 user182345. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var lightButton: UIButton!
    var lightOn = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
        // Do any additional setup after loading the view.
    }
    @IBAction func buttonPressed(_ sender: Any) {
        print("1")
        lightOn.toggle()
        updateUI()
    }
/*    func updateUI() {
        if lightOn {
            view.backgroundColor = .white
            lightButton.setTitle("Off", for: .normal)
        } else {
            view.backgroundColor = .black
            lightButton.setTitle("On", for: .normal)
        }
    }   */
    func updateUI() {
        view.backgroundColor = lightOn ? .white : .black
    }
    }
    
    
    


